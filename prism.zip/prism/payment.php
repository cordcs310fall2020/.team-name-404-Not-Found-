<div>


	<h2 align="center">Pay with Paypal:</h2>

	<p style="text-align:center;"><img src="paypal.png" width="200" height="110"/></p>





</div>