				<link rel="stylesheet" href="../styles/style.css" media="all"/>



	
		<!--Header starts from here-->
		<div class="header_wrapper">
			<a href="../../index.php"><img id="logo" src="../../Img/logo.jpg"/></a>
			<img id="banner" src="../../Img/banner.jpg"/>
			
		</div>
		<!--Header ends from here-->	
		
			<!--Navigation bar starts from here-->
			<div class="menubar">


				<ul id="menu">
					<li><a href="../../index.php">Home</a></li>
					<li><a href="../../all_products.php">Products</a></li>
					<li><a href="../../customer/settings.php">My Account</a></li>
					<li><a href="../../signup/">Sign Up</a></li>
					<li><a href="../../cart.php">Shopping Cart</a></li>
					<li><a href="../">Contact</a></li>
				</ul>

				<div id="form">
					<form method="get" action="results.php" enctype="multipart/form-data">
						<input type="text" name="user_query" placeholder= "Search a Product"/>
						<input type="submit" name="search" value="Search"/>
					</form>
				</div>
		
			</div>
